package com.in28minutes.springboot.web.model;

public interface CrudRepository<T1, T2> {

}
