package com.in28minutes.springboot.web.model;

public interface Empployeerepo extends CrudRepository<employeedetails, Integer> {

}
