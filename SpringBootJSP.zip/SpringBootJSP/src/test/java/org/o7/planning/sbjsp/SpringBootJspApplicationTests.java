package org.o7.planning.sbjsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
