package com.practice.starting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeNewApplicationTests {

	@Test
	void contextLoads() {
	}

}
